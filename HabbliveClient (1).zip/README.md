# Habblive Client Android

Cliente Android leve para abrir `https://habblive.in/mobil` como aplicativo, usando o motor WebView do próprio Android.

## Recursos

- Abre diretamente no modo mobile exigido pelo site.
- Mantém login e cookies no aparelho.
- JavaScript, armazenamento local e cache habilitados para o funcionamento do jogo.
- Botão voltar do Android navega dentro do site antes de fechar o app.
- Não precisa do Chrome aberto.
- Usa a aceleração gráfica, prioriza o renderizador do WebView e usa o cache do Android para reduzir travamentos e recarregamentos.

## Sobre a velocidade

O aplicativo já usa o motor WebView do Android com GPU e cache persistente. A velocidade de entrada nos quartos ainda depende do servidor do Habblive, da conexão e do tamanho das imagens/efeitos do quarto. Não existe um renderizador adicional que torne o servidor mais rápido; manter o **Android System WebView** atualizado é recomendado.

O Android não impõe um limite de GPU configurável pelo aplicativo. A GPU disponível depende do modelo do celular e do sistema; o app não consegue desbloquear mais potência do que o aparelho possui.

## Gerar sem computador

O arquivo `.github/workflows/build-apk.yml` permite compilar o APK pelo GitHub Actions. Depois de enviar o projeto para um repositório GitHub, abra a aba **Actions**, execute **Gerar APK do Habblive** e baixe o artefato `Habblive-debug` no celular.

## Gerar o APK

Abra esta pasta no Android Studio e use **Build > Build APK(s)**. O APK de teste será criado em `app/build/outputs/apk/debug/app-debug.apk`.

O projeto exige Android SDK 35 e Android Gradle Plugin 8.5.2.
